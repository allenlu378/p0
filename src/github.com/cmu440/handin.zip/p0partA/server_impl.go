// Implementation of a KeyValueServer. Students should write their code in this file.

package p0partA

import (
	"bytes"
	"fmt"
	"net"
	"strconv"

	"github.com/cmu440/p0partA/kvstore"
)

type keyValueServer struct {
	// TODO: implement this!
	req     chan []byte
	active  chan int
	dropped chan int
	dict    kvstore.KVStore
}

// New creates and returns (but does not start) a new KeyValueServer.
func New(store kvstore.KVStore) KeyValueServer {
	// TODO: implement this!
	return &keyValueServer{
		req:     make(chan []byte),
		active:  make(chan int),
		dropped: make(chan int),
		dict:    store,
	}
}

func (kvs *keyValueServer) requestRoutine() {
	for {
		select {
		case currRequest := <-kvs.req:
			splitRequest := bytes.Split(currRequest, []byte(":"))
			if bytes.Equal(splitRequest[0], []byte{'P', 'u', 't'}) {
				fmt.Println("Put")
				kvs.dict.Put(string(splitRequest[1]), splitRequest[2])
			} else if bytes.Equal(splitRequest[0], []byte{'G', 'e', 't'}) {
				fmt.Println("Get")
				returnedVals := kvs.dict.Get(string(splitRequest[1]))
				for _, v := range returnedVals {
					fmt.Println(v)
					// buffer := splitRequest[2]

				}
			} else if bytes.Equal(splitRequest[0], []byte{'D', 'e', 'l', 'e', 't', 'e'}) {
				fmt.Println("Delete")
				kvs.dict.Delete(string(splitRequest[1]))
			} else if bytes.Equal(splitRequest[0], []byte{'U', 'p', 'd', 'a', 't', 'e'}) {
				fmt.Println("Update")
				kvs.dict.Update(string(splitRequest[1]), splitRequest[2], splitRequest[3])
			}

		}
	}
}

func (kvs *keyValueServer) Start(port int) error {

	// TODO: implement this!
	l, err := net.Listen("tcp", "localhost"+":"+strconv.FormatInt(int64(port), 16))
	if err != nil {
		fmt.Println("Error listening:", err.Error())
	}
	// Close the listener when the application closes.
	defer l.Close()
	fmt.Println("Listening on " + "tcp" + ":" + strconv.FormatInt(int64(port), 16))

	//Start background routine
	kvs.requestRoutine()
	for {
		// Listen for an incoming connection.
		conn, err := l.Accept()
		if err != nil {
			fmt.Println("Error accepting: ", err.Error())
		}
		// Handle connections in a new goroutine.
		go kvs.handleRequest(conn)
	}
}

func (kvs *keyValueServer) handleRequest(conn net.Conn) {
	// Make a buffer to hold incoming data.
	buf := make([]byte, 5000)
	// Read the incoming connection into the buffer.
	_, err := conn.Read(buf)
	// clientWriteChannel := make(chan []byte)
	// buf = append(buf, []byte(":"+strconv.Itoa(uint(p)))...)
	//Put message onto request channel
	kvs.req <- buf

	if err != nil {
		fmt.Println("Error reading:", err.Error())
	}
	// Send a response back to person contacting us.
	conn.Write([]byte("Message received."))
	// Close the connection when you're done with it.
	// conn.Close()
}

func (kvs *keyValueServer) Close() {
	// TODO: implement this!
}

func (kvs *keyValueServer) CountActive() int {
	// TODO: implement this!
	return -1
}

func (kvs *keyValueServer) CountDropped() int {
	// TODO: implement this!
	return -1
}

// TODO: add additional methods/functions below!
